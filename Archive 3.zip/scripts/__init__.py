"""Scripts module for RAG ingestion and testing."""
