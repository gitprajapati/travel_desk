from fastapi import FastAPI, UploadFile, File, Form
from pymilvus import connections, Collection, CollectionSchema, FieldSchema, DataType
from langchain_text_splitters import RecursiveCharacterTextSplitter
import litellm
import pdfplumber
from io import BytesIO

app = FastAPI()

# ----------------------------
# AZURE OPENAI (Correct Setup)
# ----------------------------
litellm.api_type = "azure"
litellm.api_key = "D4uYdjRVT8s9WfzRgVzoNFL8wTccTemCk2sK39UjOoZHH9osmpVnJQQJ99BKACHrzpqXJ3w3AAAAACOGaGHA"
litellm.api_base = "https://sanje-mhx7nb8u-northcentralus.cognitiveservices.azure.com"
litellm.api_version = "2024-02-15-preview"

AZURE_EMBED_MODEL = "azure/text-embedding-3-small"
AZURE_CHAT_MODEL = "azure/gpt-4o"


# ----------------------------
# MILVUS CONNECTION
# ----------------------------
connections.connect(
    alias="default",
    uri="https://in03-875f9da96ae2d5f.serverless.aws-eu-central-1.cloud.zilliz.com",
    token="09117c18be9422a5f2c873c185b858bcc5a2c1566eb60ff11ff39e6bea8f8464321fa7fbb5cb03ae367899a14dc6524a97f3f1f9",
)
print("Connected to Milvus")
COLLECTION_NAME = "travel_indent_embedding1"
EMBED_DIM = 1536


# ----------------------------
# PDF AND TEXT EXTRACTION
# ----------------------------
async def extract_text(file: UploadFile):
    filename = file.filename.lower()

    raw_bytes = await file.read()

    # ----- PDF -----
    if filename.endswith(".pdf"):
        print("📄 Extracting PDF text...")
        pdf_bytes = BytesIO(raw_bytes)
        text = ""
        with pdfplumber.open(pdf_bytes) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""
        return text

    # ----- Markdown / Text -----
    print("📃 Extracting plain text...")
    return raw_bytes.decode("utf-8", errors="ignore")


# ----------------------------
# CREATE COLLECTION
# ----------------------------
def get_or_create_collection():
    from pymilvus import utility

    if COLLECTION_NAME in utility.list_collections():
        print(f"Using existing Milvus collection: {COLLECTION_NAME}")
        return Collection(COLLECTION_NAME)

    print("Creating Milvus collection:", COLLECTION_NAME)

    fields = [
        FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
        FieldSchema(name="text", dtype=DataType.VARCHAR, max_length=10000),
        FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=EMBED_DIM),
    ]

    schema = CollectionSchema(fields)
    collection = Collection(COLLECTION_NAME, schema)

    # Vector index
    collection.create_index(
        field_name="embedding",
        index_params={
            "index_type": "IVF_FLAT",
            "metric_type": "COSINE",
            "params": {"nlist": 1024}
        }
    )

    return collection


collection = get_or_create_collection()
collection.load()


# ----------------------------
# /INGEST ENDPOINT
# ----------------------------
@app.post("/ingest")
async def ingest_files(file1: UploadFile = File(...), file2: UploadFile = File(...)):

    print("📌 Step 1: Extracting text from uploaded files")
    text1 = await extract_text(file1)
    text2 = await extract_text(file2)

    combined = text1 + "\n" + text2

    print("📌 Step 2: Chunking...")
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=5000,
        chunk_overlap=200
    )
    chunks = splitter.split_text(combined)

    print(f"📌 Total chunks: {len(chunks)}")

    if not chunks:
        return {"error": "No content found."}

    # Batch embedding
    def batch(lst, n=10):
        for i in range(0, len(lst), n):
            yield lst[i:i + n]

    all_vectors = []

    print("📌 Step 3: Generating embeddings...")
    for idx, chunk_batch in enumerate(batch(chunks, 10), start=1):
        resp = litellm.embedding(model=AZURE_EMBED_MODEL, input=chunk_batch)
        vectors = [item["embedding"] for item in resp["data"]]
        all_vectors.extend(vectors)
        print(f"Embedded batch {idx}")

    print("📌 Step 4: Inserting into Milvus...")

    rows_text = chunks
    rows_vector = all_vectors

    for i in range(0, len(rows_text), 200):
        collection.insert([
            rows_text[i:i+200],
            rows_vector[i:i+200]
        ])
        collection.flush()

    print("📌 Completed ingestion successfully.")
    return {"message": "Ingested successfully", "chunks": len(chunks)}


# ----------------------------
# /CHAT ENDPOINT
# ----------------------------
@app.post("/chat")
async def rag_chat(query: str = Form(...)):
    
    print("📌 RAG Query:", query)

    # Embed query
    embed_resp = litellm.embedding(model=AZURE_EMBED_MODEL, input=query)
    query_emb = embed_resp["data"][0]["embedding"]

    # Search
    search_results = collection.search(
        data=[query_emb],
        anns_field="embedding",
        param={"metric_type": "COSINE", "params": {"nprobe": 100}},
        limit=10,
        output_fields=["text"]
    )

    hits = search_results[0]

    if len(hits) == 0:
        context = "No relevant documents found."
    else:
        context = "\n".join([hit.entity.get("text", "") for hit in hits])

    # Build prompt
    prompt = f"""
Use ONLY the following context to answer the user.

Context:
{context}

User Question:
{query}
"""

    # Generate answer
    response = litellm.completion(
        model=AZURE_CHAT_MODEL,
        messages=[
            {"role": "system", "content": "You are a helpful assistant. give answers for the travel policies. If you not sure then don't give numbers."},
            {"role": "user", "content": prompt}
        ]
    )

    answer = response["choices"][0]["message"]["content"]
    return {"answer": answer}
